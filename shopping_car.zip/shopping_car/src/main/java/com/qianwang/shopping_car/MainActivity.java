package com.qianwang.shopping_car;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.qianwang.shopping_car.adapter.LeftMenuAdapter;
import com.qianwang.shopping_car.adapter.RightMenuAdapter;
import com.qianwang.shopping_car.bean.Dish;
import com.qianwang.shopping_car.bean.DishMenu;


import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LeftMenuAdapter.onItemSelectedListener {

    private RecyclerView left_recyclerView;
    private RecyclerView right_recyclerView;
    private List<DishMenu> dishMenuList;
    private LeftMenuAdapter leftAdapter;
    private RightMenuAdapter mRightMenuAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();
        initView();
       leftAdapter.setItemSelectedListener(this);

    }

    private void initView() {

        left_recyclerView = (RecyclerView) findViewById(R.id.left_recycleView);
        right_recyclerView = (RecyclerView) findViewById(R.id.right_recycleView);

        leftAdapter = new LeftMenuAdapter(getApplicationContext(), dishMenuList);
        left_recyclerView.setAdapter(leftAdapter);
        left_recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));

        mRightMenuAdapter=new RightMenuAdapter(dishMenuList);
        right_recyclerView.setAdapter(mRightMenuAdapter);
        right_recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false));

    }

    private void initData() {
        // shopCart = new ShopCart();
        dishMenuList = new ArrayList<DishMenu>();
        ArrayList<Dish> dishs1 = new ArrayList<>();
        dishs1.add(new Dish("面包", 1.0, 10));
        dishs1.add(new Dish("蛋挞", 1.0, 10));
        dishs1.add(new Dish("牛奶", 1.0, 10));
        dishs1.add(new Dish("肠粉", 1.0, 10));
        dishs1.add(new Dish("绿茶饼", 1.0, 10));
        dishs1.add(new Dish("花卷", 1.0, 10));
        dishs1.add(new Dish("包子", 1.0, 10));
        DishMenu breakfast = new DishMenu("早点", dishs1);

        ArrayList<Dish> dishs2 = new ArrayList<>();
        dishs2.add(new Dish("粥", 1.0, 10));
        dishs2.add(new Dish("炒饭", 1.0, 10));
        dishs2.add(new Dish("炒米粉", 1.0, 10));
        dishs2.add(new Dish("炒粿条", 1.0, 10));
        dishs2.add(new Dish("炒牛河", 1.0, 10));
        dishs2.add(new Dish("炒菜", 1.0, 10));
        DishMenu launch = new DishMenu("午餐", dishs2);

        ArrayList<Dish> dishs3 = new ArrayList<>();
        dishs3.add(new Dish("淋菜", 1.0, 10));
        dishs3.add(new Dish("川菜", 1.0, 10));
        dishs3.add(new Dish("湘菜", 1.0, 10));
        dishs3.add(new Dish("粤菜", 1.0, 10));
        dishs3.add(new Dish("赣菜", 1.0, 10));
        dishs3.add(new Dish("东北菜", 1.0, 10));
        DishMenu evening = new DishMenu("晚餐", dishs3);

        ArrayList<Dish> dishs4 = new ArrayList<>();
        dishs4.add(new Dish("淋菜", 1.0, 10));
        dishs4.add(new Dish("川菜", 1.0, 10));
        dishs4.add(new Dish("湘菜", 1.0, 10));
        dishs4.add(new Dish("粤菜", 1.0, 10));
        dishs4.add(new Dish("赣菜", 1.0, 10));
        dishs4.add(new Dish("东北菜", 1.0, 10));
        DishMenu menu1 = new DishMenu("宵夜", dishs4);

        dishMenuList.add(breakfast);
        dishMenuList.add(launch);
        dishMenuList.add(evening);
        dishMenuList.add(menu1);
    }

    @Override
    public void onLeftMenuSelect(int position) {

    }
}
