package com.qianwang.shopping_car.bean;

/**
 * Created by sky on 2017/4/1.
 */

public class Dish {

    private String dishName;
    private double dishPrice;
    private int  dishAmount;
    private int  dishRemain;

    public Dish(String dishName, double dishPrice, int dishAmount) {
        this.dishName = dishName;
        this.dishPrice = dishPrice;
        this.dishAmount = dishAmount;

    }

    public String getDishName() {
        return dishName;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }

    public double getDishPrice() {
        return dishPrice;
    }

    public void setDishPrice(double dishPrice) {
        this.dishPrice = dishPrice;
    }

    public int getDishAmount() {
        return dishAmount;
    }

    public void setDishAmount(int dishAmount) {
        this.dishAmount = dishAmount;
    }

    public int getDishRemain() {
        return dishRemain;
    }

    public void setDishRemain(int dishRemain) {
        this.dishRemain = dishRemain;
    }

    @Override
    public String toString() {
        return "Dish{" +
                "dishName='" + dishName + '\'' +
                ", dishPrice=" + dishPrice +
                ", dishAmount=" + dishAmount +
                ", dishRemain=" + dishRemain +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Dish dish = (Dish) o;

        if (Double.compare(dish.dishPrice, dishPrice) != 0) return false;
        if (dishAmount != dish.dishAmount) return false;
        if (dishRemain != dish.dishRemain) return false;
        return dishName != null ? dishName.equals(dish.dishName) : dish.dishName == null;

    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = dishName != null ? dishName.hashCode() : 0;
        temp = Double.doubleToLongBits(dishPrice);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + dishAmount;
        result = 31 * result + dishRemain;
        return result;
    }
}
